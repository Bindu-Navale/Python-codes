str1=input("Enter your first name: ")
str2=input("Enter your second name: ")
name=str1+" "+str2
print(f"Hi!! {name}. Welcome to the python program")
